================================================================================
Run8 eMV - AEI Reader & Detector Monitor
================================================================================

A live Automated Equipment Identification (AEI) and defect detector XML monitor 
built for Run8 Train Simulator (V3 & V4). Automatically parses detector scanner 
XML outputs, cleans up stale session data on startup, and feeds clean consist, 
tonnage, length, and location updates into your live dispatch and tracking 
workflow.

--------------------------------------------------------------------------------
WHAT'S NEW IN THIS UPDATE
--------------------------------------------------------------------------------
* Automatic Startup XML Purge: Clears leftover detector XML files and resets 
  cached session state on launch so old consists or ghost reads never carry 
  over from a previous session.
* Standardized Detector & Milepost Keys: Aligns detector and milepost 
  identifiers across subdivisions so downstream tools (CAD Train Sheet and 
  Live Map) stay completely synchronized.
* Run8 V4 Beta Compatibility: Verified with current Run8 V4 beta builds and 
  multi-subdivision detector outputs.

--------------------------------------------------------------------------------
FEATURES
--------------------------------------------------------------------------------
* Real-Time XML Watching: Continuously monitors your Run8 detector/AEI output 
  folder for incoming scanner reports.
* Full Consist & Detector Parsing: Extracts train symbols, locomotive 
  reporting marks and road numbers, train speed, total tonnage, train length, 
  and scanner/milepost location.
* Safe File Filtering: Automatically ignores static configuration, routing, 
  and master files during both startup purges and live polling.
* Clean Session Reset: Ensures every Run8 session starts with an empty board 
  and populates strictly from live detector triggers.

--------------------------------------------------------------------------------
SETUP & USAGE
--------------------------------------------------------------------------------
1. Launch the AEI Reader:
   Run the AEI executable or Python script before or right as you start your 
   Run8 session.

2. Select Your Watch Folder:
   Click "Browse..." and point the watcher to your active Run8 XML output 
   folder.

   IMPORTANT: Make sure you select your live XML output directory. Do NOT point 
   the watcher at a folder containing backup XMLs or route configuration files 
   you wish to keep.

3. Start Monitoring:
   Verify that the "Purge XMLs on startup" option is enabled (recommended) and 
   click "Start".

4. Run Your Session:
   As trains pass AEI readers and defect detectors in Run8, live reports will 
   automatically parse and update in real time.

--------------------------------------------------------------------------------
TROUBLESHOOTING
--------------------------------------------------------------------------------
* No trains appearing on the board:
  Confirm Run8 is actively generating detector XMLs into the selected watch 
  folder and that a train has passed an active scanner since you clicked Start.

* Old trains showing up from yesterday's session:
  Ensure "Purge XMLs on startup" is checked before clicking Start, or use the 
  "Clear" button to reset the active board manually.
================================================================================