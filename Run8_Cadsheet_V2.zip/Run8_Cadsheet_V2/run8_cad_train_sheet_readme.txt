================================================================================
Run8 eMV - CAD Train Sheet Generator
================================================================================

A real-time web-based Computer-Aided Dispatch (CAD) Train Sheet for Run8 Train 
Simulator (V3 & V4). Watches incoming defect detector and AEI XML files, 
automatically identifies the active subdivision, and displays live 
eastbound/westbound train movements in a clean dispatcher board in your browser.

--------------------------------------------------------------------------------
WHAT'S NEW IN THIS UPDATE
--------------------------------------------------------------------------------
* Startup XML Purge & Board Reset: Added an automatic startup purge (with a 
  toggleable "Purge existing XML files on startup" checkbox) that clears stale 
  .xml files from your watch folder and resets trains.json on launch, 
  eliminating ghost trains from previous sessions.
* Synchronized Startup Behavior: Matches the startup cleanup workflow of the 
  AEI Reader so both tools start from a clean slate together.
* Status Display Fix: Improved folder status reporting when clearing the active 
  dispatch sheet mid-session.

--------------------------------------------------------------------------------
FEATURES
--------------------------------------------------------------------------------
* Live Browser Dispatch Board: Automatically launches a local web server 
  (http://localhost:8080/train_sheet.html) that refreshes every 2 seconds with 
  zero manual page reloads.
* Automatic Subdivision Detection: Matches detector mileposts and scanner names 
  across major Run8 corridors -- including CSX (Mohawk, Selkirk, Hudson, River, 
  Lineville, Jesup, Savannah, Charleston, Sanford, Nahunta, Fitzgerald, 
  Manchester, Callahan), NS (Pittsburgh, AGS), BNSF (Needles, Seligman, 
  Bakersfield, Stockton, San Bernardino, Cajon), and UP (Donner, Mojave, 
  Fresno, Roseville).
* Complete Train Sheet Columns: Displays Route, Train Symbol, Lead Road/Ident, 
  Unit Number, Speed (MPH), OS Time, Tonnage, Train Length (FT), and Detector 
  Location.
* One-Click Train Removal: Remove terminated or annulled trains individually 
  using the "X" button on any row, or wipe the entire sheet with "Clear All".

--------------------------------------------------------------------------------
SETUP & USAGE
--------------------------------------------------------------------------------
1. Launch Run8_Cadsheet:
   Open the CAD Train Sheet application.

2. Select Your XML Watch Folder:
   Click "Browse..." and choose the folder where Run8 outputs detector XML files.

   IMPORTANT: Always point the watcher to your live XML output folder. Because 
   the startup purge deletes stale .xml files in that directory, never select a 
   folder containing backup XMLs you want to keep.

3. Start the CAD Sheet:
   Leave "Purge existing XML files on startup" checked (default) and click 
   "Start CAD Sheet". Your default web browser will automatically open the 
   live train sheet.

4. Manage Active Trains:
   - Click "X" next to any train row in the browser to remove that train from 
     the sheet.
   - Click "Clear All" in the watcher window to reset the entire board at any 
     time.
   - Click "Stop CAD Sheet" when your session is finished.

--------------------------------------------------------------------------------
SYSTEM REQUIREMENTS & NOTES
--------------------------------------------------------------------------------
* Port 8080: The built-in local web server runs on localhost:8080. Make sure no 
  other local utility is occupying port 8080 before starting the watcher.
* Safe Config Handling: Files containing ROUTING, CONFIG, MASTER, or SETTINGS 
  in their filenames are automatically skipped during startup purges and live 
  scans.
================================================================================